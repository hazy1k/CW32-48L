keilkill.bat说明：

1. 清除编译、链接等中间过程中生成的文件
